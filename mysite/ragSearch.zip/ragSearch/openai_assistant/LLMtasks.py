from flask import Flask, jsonify, request
from flask_cors import CORS
import dataloader
app = Flask(__name__)
CORS(app)

@app.route('/run-python-function', methods=['GET'])
def run_python_function():
    param = request.args.get('param', 'default value')

    def load_url_and_transform_txt_to_html(url):
        loader = dataloader.UnstructuredURLLoader(urls=url)
        data = loader.load()
        html_2_text = dataloader.transform_html_to_text(data)
        return html_2_text

    try:
        result = load_url_and_transform_txt_to_html(param)
        return jsonify({'status': 'success', 'result': result})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
