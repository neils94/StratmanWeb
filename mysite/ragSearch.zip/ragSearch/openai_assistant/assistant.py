import openai
a = 1