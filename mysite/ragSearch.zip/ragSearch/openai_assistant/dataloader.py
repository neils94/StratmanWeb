from langchain.document_loaders import UnstructuredURLLoader
from langchain.document_transformers import Html2TextTransformer
import datetime



def load_url(url):
    loader = UnstructuredURLLoader(urls=url)
    data = loader.load()
    return data
def transform_html_to_text(data):
    transformer = Html2TextTransformer()
    transformed = transformer.transform_documents(data)
    return transformed[0].page_content[:]

today = datetime.date.today()
one_day_from_today = today + datetime.timedelta(days=90)

url = ["https://financialmodelingprep.com/api/v3/earning_calendar?from={today}&to={one_day_from_today}&apikey=Zz7Qx2LHXU3lAzgtKyx4G93NENgtxm3V"]

data = load_url(url)
t2h = transform_html_to_text(data)

print(t2h)