from flask import Flask
from flask_cors import CORS
import dataloader
import datetime
from MapReduceDocs import MapReduceDocs

app = Flask(__name__)
CORS(app)
today = datetime.date.today()
one_earnings_cycle = today + datetime.timedelta(days=90)
prev_earnings_cycle = today - datetime.timedelta(days=90)
mapReduce = MapReduceDocs()

hotkey_dict = {'SA':["https://financialmodelingprep.com/api/v4/social-sentiments/change?type=bullish&source=stocktwits"], 
               'ER': ["https://financialmodelingprep.com/api/v4/earning-calendar-confirmed?from={today}&to={prev_earnings_cycle}&apikey=Zz7Qx2LHXU3lAzgtKyx4G93NENgtxm3V"] , 
               'UE': ["https://financialmodelingprep.com/api/v3/earning_calendar?from={today}&to={one_earnings_cycle}&apikey=Zz7Qx2LHXU3lAzgtKyx4G93NENgtxm3V"], 
               'N':["https://financialmodelingprep.com/api/v3/stock_news?page=0"], 
               'AR':["https://financialmodelingprep.com/api/v3/analyst-stock-recommendations/{stock_ticker}?apikey=Zz7Qx2LHXU3lAzgtKyx4G93NENgtxm3V"]}
@app.route('/call-llm-chain', methods=['GET'])
def call_llm_chain(stock_ticker: str, hotkey):
    url = hotkey_dict[hotkey] 
            
    loader =  dataloader.UnstructuredURLLoader(urls=url)
    data =  loader.load()
    html_2_text =  dataloader.transform_html_to_text(data)
        
    return html_2_text

"""
if __name__ == '__main__':
    app.run(debug=True)
"""
chain  = call_llm_chain("TCOM", 'ER')

print(chain[0][0]["symbol"]["revenue"])