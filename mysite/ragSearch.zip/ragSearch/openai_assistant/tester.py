import requests
import datetime

today = datetime.date.today()
one_earnings_cycle = today + datetime.timedelta(days=30)

url = "https://financialmodelingprep.com/api/v3/earning_calendar?from={today}&to={one_earnings_cycle}&apikey=Zz7Qx2LHXU3lAzgtKyx4G93NENgtxm3V"

getter = requests.get(url)
getter_dict = getter.json()

"""
def get_ue(ticker):
    for i in range(1):
        for i in (getter_dict):
            if ticker == i['symbol']:
                return i['date'], i['eps'], i['epsEstimated'], i['revenue'], i['revenueEstimated']
"""
print(len(getter_dict))